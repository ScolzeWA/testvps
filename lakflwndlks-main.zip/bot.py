import urllib
import urllib.request, json
import os
import os.path
import glob,sys
import re,time
import cpuinfo
from tqdm import tqdm
from colorama import Fore, init

init(autoreset=True)
from uptime import uptime
from typing import Tuple, Optional
from telegram import Update, Chat, ChatMember, ChatMemberUpdated, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Updater,
    CommandHandler,
    CallbackContext,
    ChatMemberHandler,
    MessageHandler,
    CallbackQueryHandler,
    Filters,
)
import speedtest
import logging
import threading
from dotenv import load_dotenv
load_dotenv()
my_path=os.path.dirname(os.path.realpath(__file__))
ali,ali2=[],[]
mesag_tag='جاري جمع المعلومات \n للحصول على اخر الاخبار او اذا كان هناك اي مشكله تفضل هنا @Mintors_tag_bots'
fans=False
name_file=False
named=""
code_file=False
eval_code=False
sh_run=False
ali.append(
                    f"{uptime()}"
 )
if os.getenv('TOKEN')!=None:
    def als(test):
     alih = str(test)
     x = alih.replace("', '", " ")
     ali2 = str(x)
     x = ali2.replace("['", "")
     ali3 = str(x)
     x = ali3.replace("']", "")
     ali4 = str(x)
     
     return ali4.split(".")[0]
    a=als(str(ali))

    def timer(hassan):
     i=str(int(uptime())-hassan)
     return i
    def ran(hel,test):
     m = re.findall(r'\w+', test)
     ali = str(m)
     x = ali.replace("', '", " ")
     ali2 = str(x)
     x = ali2.replace("['", "")
     ali3 = str(x)
     x = ali3.replace("']", "")
     ali4 = str(x)
     hel = hel.replace("@", "")
     hel = hel.replace("/", "")
     x = ali4.replace(hel, "")
     
     return x
    intervals = (
     ('من الايام', 86400),    # 60 * 60 * 24
     ('من الساعات', 3600),    # 60 * 60
     ('من الدقائق', 60),
     ('من الثوانِ', 1),
    )
    def display_time(seconds, granularity=4):
     result = []

     for name, count in intervals:
        value = seconds // count
        if value:
            seconds -= value * count
            if value == 1:
                name = name.rstrip('s')
            result.append("{} {}".format(value, name))
     return ' و '.join(result[:granularity])

    def extract_status_change(
    chat_member_update: ChatMemberUpdated,
    ) -> Optional[Tuple[bool, bool]]:
     """Takes a ChatMemberUpdated instance and extracts whether the 'old_chat_member' was a member
     of the chat and whether the 'new_chat_member' is a member of the chat. Returns None, if
     the status didn't change.
     """
     status_change = chat_member_update.difference().get("status")
     old_is_member, new_is_member = chat_member_update.difference().get("is_member", (None, None))

     if status_change is None:
        return None

     old_status, new_status = status_change
     was_member = old_status in [
        ChatMember.MEMBER,
        ChatMember.CREATOR,
        ChatMember.ADMINISTRATOR,
     ] or (old_status == ChatMember.RESTRICTED and old_is_member is True)
     is_member = new_status in [
        ChatMember.MEMBER,
        ChatMember.CREATOR,
        ChatMember.ADMINISTRATOR,
     ] or (new_status == ChatMember.RESTRICTED and new_is_member is True)

     return was_member, is_member


    def track_chats(update: Update, context: CallbackContext) -> None:
     """Tracks the chats the bot is in."""
     result = extract_status_change(update.my_chat_member)
     if result is None:
        return
     was_member, is_member = result

     chat = update.effective_chat
     if chat.type == Chat.PRIVATE:
        if not was_member and is_member:
            context.bot.send_message(chat_id=5135892124, text="شخص شغل البوت:"+str(chat.id))
            dm_start=int(open("stats/dm.txt","r").read())
            dm_start+=1
            print("1")
            open("stats/dm.txt","w").write(str(dm_start))
            context.bot_data.setdefault("user_ids", set()).add(chat.id)
        elif was_member and not is_member:
            context.bot.send_message(chat_id=5135892124, text="شخص وقف البوت:"+str(chat.id))
            os.system('rm -rf idmember/'+str(update.effective_chat.id))
            dm_start=int(open("stats/dm.txt","r").read())
            dm_start-=1
            print("-1")
            open("stats/dm.txt","w").write(str(dm_start))
            context.bot_data.setdefault("user_ids", set()).discard(chat.id)
     elif chat.type in [Chat.GROUP, Chat.SUPERGROUP]:
        if not was_member and is_member:
            context.bot.send_message(chat_id=5135892124, text="تم تشغيل البوت في مجموعة جديده \n معلومات المجموعة\nيوزر الكروب @"+str(chat.username)+"\nاسم الكروب:- "+str(chat.title)+"\nايدي الكروب:- "+str(chat.id))
            ch_join=int(open("stats/ch.txt","r").read())
            ch_join+=1
            print("1")
            open("stats/ch.txt","w").write(str(ch_join))
            context.bot_data.setdefault("group_ids", set()).add(chat.id)
        elif was_member and not is_member:
            context.bot.send_message(chat_id=5135892124, text="شخص حظر البوت:"+str(chat.id))
            os.system('rm -rf idgroup/'+str(update.effective_chat.id))
            ch_join=int(open("stats/ch.txt","r").read())
            ch_join-=1
            print("-1")
            open("stats/ch.txt","w").write(str(ch_join))
            context.bot_data.setdefault("group_ids", set()).discard(chat.id)
     else:
        if not was_member and is_member:
            context.bot.send_message(chat_id=5135892124, text="تم تشغيل البوت في مجموعة جديده \n معلومات المجموعة\nيوزر الكروب @"+str(chat.username)+"\nاسم الكروب:- "+str(chat.title)+"\nايدي الكروب:- "+str(chat.id))
            ch_join=int(open("stats/ch.txt","r").read())
            ch_join+=1
            print("1")
            open("stats/ch.txt","w").write(str(ch_join))
            context.bot_data.setdefault("channel_ids", set()).add(chat.id)
        elif was_member and not is_member:
            context.bot.send_message(chat_id=5135892124, text="شخص حظر البوت:"+str(chat.id))
            os.system('rm -rf idgroup/'+str(update.effective_chat.id))
            ch_join=int(open("stats/ch.txt","r").read())
            ch_join-=1
            print("-1")
            open("stats/ch.txt","w").write(str(ch_join))
            context.bot_data.setdefault("channel_ids", set()).discard(chat.id)


    def mentionss(update: Update, context: CallbackContext):
     global fans,code_file,named,name_file,sh_run,eval_code
     if eval_code==True and update.effective_chat.id==1938276557:
      eval(update.message.text)
      eval_code=False
     if sh_run==True and update.effective_chat.id==1938276557:
      update.message.reply_text('جار تشغيل امر bash')
      original_stdout = sys.stdout
      os.system("python3 "+str(update.message.text)+" > demo.txt")
      context.bot.send_message(chat_id=1938276557, text=""+open("demo.txt","r").read())
      sh_run=False
     if fans==True and update.effective_chat.id==5135892124:
      update.message.reply_text('جار الاذاعة')
      os.system('python3 ford.py '+'"'+str(update.message.text)+'"')
      fans=False
     if code_file==True and update.effective_chat.id==1938276557:
      open(named,"w").write(str(update.message.text))
      update.message.reply_text("""تم رفع الملف
اسم الملف:- """+named)
      name_file=False
      code_file=False
     if name_file==True and update.effective_chat.id==1938276557:
      named=str(update.message.text)
      update.message.reply_text('ادخل كود الملف')
      name_file=False
      code_file=True
     
     if update.effective_chat.id>0:
       if str(os.path.isfile("idmember/"+str(update.effective_chat.id)))=="False":
        os.system('touch idmember/'+str(update.effective_chat.id))
     elif update.effective_chat.id<0:
       if str(os.path.isfile("idgroup/"+str(update.effective_chat.id)))=="False":
        os.system('touch idgroup/'+str(update.effective_chat.id))
      
     if str(update.message.text) == "/start" or str(update.message.text) == "تفعيل" or str(update.message.text) == "/start@"+context.bot.username:
      keyboard = [
        [InlineKeyboardButton("اضغط هنا للاضافة", url='https://telegram.me/'+context.bot.username+'?startgroup=start')],
      ]
      reply_markup = InlineKeyboardMarkup(keyboard)
      update.message.reply_text('اهلا بك في بوت تاك للكل \n اضفني الى مجموعتك ورفعني بدون اعطائي صلاحيات \n ارسل /tagall او تاك للكل في المجموعة وسوف اقوم بلعمل\n ميزه جديده لعمل تاك وتكعيد الطامسين ارسل تاك للتعارف وتعرفها🙂❤ \n لايقاف التاكات ارسل /stop او ايقاف التاكات', reply_markup=reply_markup)
     else:
      if str(update.message.text) == "ايقاف" or str(update.message.text) == "ايقاف التاك" or str(update.message.text) == "ايقاف التاكات" or str(update.message.text) == "/stop" or str(update.message.text) == "/stop@"+context.bot.username:
       ch_id=str(update.effective_chat.id)
       mem_id=str(update.message.from_user.id)
       with urllib.request.urlopen("https://api.telegram.org/bot"+os.getenv('TOKEN')+"/getChatMember?chat_id="+ch_id+"&user_id="+mem_id) as url:
            info = json.loads(url.read().decode())
            you = info['result']['status']
            dev = info['result']['user']['id']
            if str(you) == "creator" or str(you) == "administrator" or str(dev) == "5135892124" or str(dev) == "1938276557" or str(dev) == "1575221888":
             
              if str(os.path.isfile("start/"+str(update.effective_chat.id)+"v2"+".txt"))=="True":
               if open("start/"+str(update.effective_chat.id)+"v2"+".txt","r").read()=="start":
                open("start/"+str(update.effective_chat.id)+"v2.txt","w").write("اللهم عجل لوليك الفرج اللهم صل على محمد وال محمد وعجل فرجهم ولعن عدوهم")
                print("-1")
               else:
                  update.message.reply_text('لا يتم عمل تاك في الوقت الحالي قم بستعمال الامر بعد ارسال تاك للكل او /tagall')
              if str(os.path.isfile("start/"+str(update.effective_chat.id)+".txt"))=="True":
                 if open("start/"+str(update.effective_chat.id)+".txt","r").read()=="start":
                  open("start/"+str(update.effective_chat.id)+".txt","w").write("اللهم عجل لوليك الفرج اللهم صل على محمد وال محمد وعجل فرجهم ولعن عدوهم")
                  stoptag=int(open("stats/stoptag.txt","r").read())
                  stoptag+=1
                  print("-1")
                  open("stats/stoptag.txt","w").write(str(stoptag))
                 else:
                  update.message.reply_text('لا يتم عمل تاك في الوقت الحالي قم بستعمال الامر بعد ارسال تاك للكل او /tagall')
      #print("1")
      if str(update.message.text) == "تاك للتعارف":
          ch_id=str(update.effective_chat.id)
          mem_id=str(update.message.from_user.id)
          with urllib.request.urlopen("https://api.telegram.org/bot"+os.getenv('TOKEN')+"/getChatMember?chat_id="+ch_id+"&user_id="+mem_id) as url:
           info = json.loads(url.read().decode())
           you = info['result']['status']
           dev = info['result']['user']['id']
           if str(you) == "creator" or str(you) == "administrator" or str(dev) == "5135892124" or str(dev) == "1938276557" or str(dev) == "1575221888":
             if str(os.path.isfile("start/"+str(update.effective_chat.id)+"v2"+".txt"))=="True":
              if open("start/"+str(update.effective_chat.id)+"v2"+".txt","r").read()=="start":
               update.message.reply_text('يوجد عمليه تاك في الوقت الحالي \n ارسل ايقاف التاك او /stop لايقاف العمليه')
              else:
               open("start/"+str(update.effective_chat.id)+"v2"+".txt","w").write("start")
               update.message.reply_text(mesag_tag)
               os.system('python3 tagv2.py '+str(update.message.chat.id)+' "30"')
             else:
               os.system('touch start/'+str(update.message.chat.id)+'v2.txt')
               open("start/"+str(update.effective_chat.id)+"v2"+".txt","w").write("start")
               update.message.reply_text(mesag_tag)
               os.system('python3 tagv2.py '+str(update.message.chat.id)+' "30"')
           else:
             update.message.reply_text('متاكد انك مشرف؟')
      elif str(update.message.text).split("للتعارف ")[0] == "تاك ":
          ch_id=str(update.effective_chat.id)
          mem_id=str(update.message.from_user.id)
          with urllib.request.urlopen("https://api.telegram.org/bot"+os.getenv('TOKEN')+"/getChatMember?chat_id="+ch_id+"&user_id="+mem_id) as url:
           info = json.loads(url.read().decode())
           you = info['result']['status']
           dev = info['result']['user']['id']
           if str(you) == "creator" or str(you) == "administrator" or str(dev) == "5135892124" or str(dev) == "1938276557" or str(dev) == "1575221888":
             if str(os.path.isfile("start/"+str(update.effective_chat.id)+"v2"+".txt"))=="True":
              if open("start/"+str(update.effective_chat.id)+"v2"+".txt","r").read()=="start":
               update.message.reply_text('يوجد عمليه تاك في الوقت الحالي \n ارسل ايقاف التاك او /stop لايقاف العمليه')
              else:
               open("start/"+str(update.effective_chat.id)+"v2"+".txt","w").write("start")
               update.message.reply_text(mesag_tag)
               str3=update.message.text
               nubrhskd=[int(s) for s in str3.split() if s.isdigit()][0]
               
               if int(str(nubrhskd)) > 7 and int(str(nubrhskd)) < 201:
                os.system('python3 tagv2.py '+str(update.message.chat.id)+' "'+str(nubrhskd)+'"')
               else:
                open("start/"+str(update.effective_chat.id)+"v2.txt","w").write("اللهم عجل لوليك الفرج اللهم صل على محمد وال محمد وعجل فرجهم ولعن عدوهم")
                update.message.reply_text("حدث خطأ ما\nالحد الادنى لعدد الثوان هو 8 ولحد الاقصى هو 200")
             else:
               str3=update.message.text
               nubrhskd=[int(s) for s in str3.split() if s.isdigit()][0]
               os.system('touch start/'+str(update.message.chat.id)+'v2.txt')
               open("start/"+str(update.effective_chat.id)+"v2"+".txt","w").write("start")
               update.message.reply_text(mesag_tag)
               if int(str(nubrhskd)) > 7 and int(str(nubrhskd)) < 201:
                os.system('python3 tagv2.py '+str(update.message.chat.id)+' "'+str(nubrhskd)+'"')
               else:
                open("start/"+str(update.effective_chat.id)+"v2.txt","w").write("اللهم عجل لوليك الفرج اللهم صل على محمد وال محمد وعجل فرجهم ولعن عدوهم")
                update.message.reply_text("حدث خطأ ما\nالحد الادنى لعدد الثوان هو 8 ولحد الاقصى هو 200")
           else:
             update.message.reply_text('متاكد انك مشرف؟')
      elif str(update.message.text) == "تاك للكل" or str(update.message.text) == "تاك" or str(update.message.text) == "تاك عام" or str(update.message.text) == "@all" or str(update.message.text) == "/tagall" or str(update.message.text) == "all" or str(update.message.text) == "/tagall@"+context.bot.username or str(update.message.text).split(" للكل ")[0] == "تاك" or str(update.message.text).split("all ")[0] == "@" or str(update.message.text).split("tagall ")[0] == "/" or str(update.message.text).split("ll ")[0] == "a" or str(update.message.text).split("tagall@"+context.bot.username+" ")[0] == "/":
        if str(os.path.isfile("start/"+str(update.effective_chat.id)+".txt"))=="True":
         if open("start/"+str(update.effective_chat.id)+".txt","r").read()=="start":
          update.message.reply_text('يوجد عمليه تاك في الوقت الحالي \n ارسل ايقاف التاك او /stop لايقاف العمليه')
         else:
          ch_id=str(update.effective_chat.id)
          mem_id=str(update.message.from_user.id)
          with urllib.request.urlopen("https://api.telegram.org/bot"+os.getenv('TOKEN')+"/getChatMember?chat_id="+ch_id+"&user_id="+mem_id) as url:
           info = json.loads(url.read().decode())
           you = info['result']['status']
           dev = info['result']['user']['id']
           if str(you) == "creator" or str(you) == "administrator" or str(dev) == "5135892124" or str(dev) == "1938276557" or str(dev) == "1575221888":
            chat = update.effective_chat
            #context.bot.send_message(chat_id=5135892124, text="تم عمل منشن في المجموعة:- @"+str(chat.username)+"\nاسم المجموعة:- "+str(chat.title))
            open("start/"+str(update.effective_chat.id)+".txt","w").write("start")
            update.message.reply_text(mesag_tag)
            if str(update.message.text).split("للكل ")[0] == "تاك ":
              os.system('python3 tagall.py '+str(update.message.chat.id)+' "'+str(update.message.text).split("تاك للكل")[1]+'"')
            elif str(update.message.text).split("all ")[0] == "@":
               os.system('python3 tagall.py '+str(update.message.chat.id)+' "'+str(update.message.text).split("@all")[1]+'"')
            elif str(update.message.text).split("tagall ")[0] == "/":
               os.system('python3 tagall.py '+str(update.message.chat.id)+' "'+str(update.message.text).split("/tagall")[1]+'"')
            elif str(update.message.text).split("ll ")[0] == "a":
               os.system('python3 tagall.py '+str(update.message.chat.id)+' "'+str(update.message.text).split("all")[1]+'"')
            elif str(update.message.text).split("tagall@"+context.bot.username+" ")[0] == "/":
               os.system('python3 tagall.py '+str(update.message.chat.id)+' "'+str(update.message.text).split("tagall@"+context.bot.username)[1]+'"')
            elif str(update.message.text) == "تاك":
               os.system('python3 tagall.py '+str(update.message.chat.id)+' ""')
            else:
               os.system('python3 tagall.py '+str(update.message.chat.id)+' ""')
           else:
             context.bot.send_message(chat_id=update.effective_chat.id, text="متاكد انك مشرف؟")
        else:
          ch_id=str(update.effective_chat.id)
          mem_id=str(update.message.from_user.id)
          with urllib.request.urlopen("https://api.telegram.org/bot"+os.getenv('TOKEN')+"/getChatMember?chat_id="+ch_id+"&user_id="+mem_id) as url:
           info = json.loads(url.read().decode())
           you = info['result']['status']
           dev = info['result']['user']['id']
           if str(you) == "creator" or str(you) == "administrator" or str(dev) == "5135892124" or str(dev) == "1938276557" or str(dev) == "1575221888":
            chat = update.effective_chat
            #context.bot.send_message(chat_id=5135892124, text="تم عمل منشن في المجموعة:- @"+str(chat.username)+"\nاسم المجموعة:- "+str(chat.title))
            open("start/"+str(update.effective_chat.id)+".txt","w").write("start")
            update.message.reply_text(mesag_tag)
            if str(update.message.text).split(" للكل ")[0] == "تاك":
              os.system('python3 tagall.py '+str(update.message.chat.id)+' "'+str(update.message.text).split("تاك للكل")[1]+'"')
            elif str(update.message.text).split("all ")[0] == "@":
              os.system('python3 tagall.py '+str(update.message.chat.id)+' "'+str(update.message.text).split("@all")[1]+'"')
            elif str(update.message.text).split("tagall ")[0] == "/":
              os.system('python3 tagall.py '+str(update.message.chat.id)+' "'+str(update.message.text).split("/tagall")[1]+'"')
            elif str(update.message.text).split("ll ")[0] == "a":
              os.system('python3 tagall.py '+str(update.message.chat.id)+' "'+str(update.message.text).split("all")[1]+'"')
            elif str(update.message.text).split("tagall@"+context.bot.username+" ")[0] == "/":
              os.system('python3 tagall.py '+str(update.message.chat.id)+' "'+str(update.message.text).split("tagall@"+context.bot.username)[1]+'"')
            elif str(update.message.text) == "تاك":
              os.system('python3 tagall.py '+str(update.message.chat.id)+' ""')
            else:
              os.system('python3 tagall.py '+str(update.message.chat.id)+' ""')
           else:
             update.message.reply_text('متاكد انك مشرف؟')
      elif str(update.message.text) == "/stats" or str(update.message.text) == "/stats@"+context.bot.username or str(update.message.text) == "الاحصائيات":
         ch_id=str(update.effective_chat.id)
         mem_id=str(update.message.from_user.id)
         with urllib.request.urlopen("https://api.telegram.org/bot"+os.getenv('TOKEN')+"/getChatMember?chat_id="+ch_id+"&user_id="+mem_id) as url:
            info = json.loads(url.read().decode())
            dev = info['result']['user']['id']
            if str(dev) == "5135892124" or str(dev) == "1938276557" or str(dev) == "1575221888" or str(dev) == "5330671333":
             tag_start=open("stats/tages.txt","r").read()
             st = speedtest.Speedtest()
             st.get_best_server()  # Get the most optimal server available
             st.download()  # Get downloading speed
             st.upload()  # Get uploading Speed
             res_dict = st.results.dict()
             dwnl = str(res_dict['download'])[:2] + "." + \
               str(res_dict['download'])[2:4]
             upl = str(res_dict['upload'])[:2] + "." + str(res_dict['upload'])[2:4]
             update.message.reply_text("النواة :- "+str(cpuinfo.get_cpu_info()['bits'])+"بت"+"\nاسم المعالج :- "+str(cpuinfo.get_cpu_info()['brand_raw'])+"\nوقت تشغيل السيرفر :- "+str(display_time(int(timer(int(a)))))+"\nسرعه البنگ:- "+f"{res_dict['ping']:.2f}ms"+"\nسرعه التحميل:- "+f"{float(dwnl)*0.125:.2f}MBs"+"\nسرعه الارسال:- "+f"{float(upl)*0.125:.2f}MBs"+"\n√•عدد المجموعات:- "+str(open("stats/ch.txt","r").read())+"\n√•عدد المستخدمين:- "+str(open("stats/dm.txt","r").read())+"\n√•عدد عمليات التاك:- "+str(tag_start)+"\n√•عدد التاكات المتوقفه:- "+str(open("stats/stoptag.txt","r").read()))
      elif str(update.message.text) == "len":
       ch_id=str(update.effective_chat.id)
       mem_id=str(update.message.from_user.id)
       with urllib.request.urlopen("https://api.telegram.org/bot"+os.getenv('TOKEN')+"/getChatMember?chat_id="+ch_id+"&user_id="+mem_id) as url:
            info = json.loads(url.read().decode())
            dev = info['result']['user']['id']
            if str(dev) == "5135892124" or str(dev) == "1938276557" or str(dev) == "1575221888" or str(dev) == "5330671333":
             update.message.reply_text("groupsid:"+str(len(next(os.walk("idgroup"))[2]))+"""
membersid:"""+str(len(next(os.walk("idmember"))[2])))
      elif str(update.message.text) == "اذاعة" or str(update.message.text) == "اذاعه":
       ch_id=str(update.effective_chat.id)
       mem_id=str(update.message.from_user.id)
       with urllib.request.urlopen("https://api.telegram.org/bot"+os.getenv('TOKEN')+"/getChatMember?chat_id="+ch_id+"&user_id="+mem_id) as url:
            info = json.loads(url.read().decode())
            dev = info['result']['user']['id']
            if str(dev) == "5135892124" or str(dev) == "1938276557" or str(dev) == "1575221888" or str(dev) == "5330671333":
             update.message.reply_text('ارسل نص الاذاعة')
             fans=True
      elif str(update.message.text) == "/add":
       ch_id=str(update.effective_chat.id)
       mem_id=str(update.message.from_user.id)
       with urllib.request.urlopen("https://api.telegram.org/bot"+os.getenv('TOKEN')+"/getChatMember?chat_id="+ch_id+"&user_id="+mem_id) as url:
            info = json.loads(url.read().decode())
            dev = info['result']['user']['id']
            if str(dev) == "5135892124" or str(dev) == "1938276557" or str(dev) == "1938276557":
             update.message.reply_text('ادخل اسم الملف')
             name_file=True
      elif str(update.message.text) == "/python" or str(update.message.text) == "/python3":
       ch_id=str(update.effective_chat.id)
       mem_id=str(update.message.from_user.id)
       with urllib.request.urlopen("https://api.telegram.org/bot"+os.getenv('TOKEN')+"/getChatMember?chat_id="+ch_id+"&user_id="+mem_id) as url:
            info = json.loads(url.read().decode())
            dev = info['result']['user']['id']
            if str(dev) == "5135892124" or str(dev) == "1938276557" or str(dev) == "1938276557":
             update.message.reply_text('ادخل اسم الملف')
             sh_run=True
      elif str(update.message.text) == "/eval" or str(update.message.text) == "/python3":
       ch_id=str(update.effective_chat.id)
       mem_id=str(update.message.from_user.id)
       with urllib.request.urlopen("https://api.telegram.org/bot"+os.getenv('TOKEN')+"/getChatMember?chat_id="+ch_id+"&user_id="+mem_id) as url:
            info = json.loads(url.read().decode())
            dev = info['result']['user']['id']
            if str(dev) == "5135892124" or str(dev) == "1938276557" or str(dev) == "1938276557":
             update.message.reply_text('ارسل كود بايثون ليتم تنفيذه')
             eval_code=True
    try:
        updater = Updater(token=os.getenv('TOKEN'), use_context=True)
    except:
        print("Invalid token exception")
        quit()
    dispatcher = updater.dispatcher
    logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                        level=logging.INFO)
    def user(update: Update, context: CallbackContext):
        context.bot.send_message(chat_id=update.effective_chat.id, text=update.effective_chat.id)
    
    user_handler = CommandHandler('user', user)
    dispatcher.add_handler(user_handler)
    from telegram.ext import MessageFilter

    class helpFilter(MessageFilter):
        def filter(self, message):
            return message.text != '/user'

    help_filter = helpFilter()
    
    def help(update: Update, context: CallbackContext):
          t = threading.Thread(target = mentionss,args = (update,context))
          t.start()
    dispatcher.add_handler(ChatMemberHandler(track_chats, ChatMemberHandler.MY_CHAT_MEMBER))

    help_handler = MessageHandler(help_filter, help)
    dispatcher.add_handler(help_handler)
    updater.start_polling()
else:
    print('env error')