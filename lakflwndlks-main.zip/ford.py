from telethon import TelegramClient, sync
import os
from dotenv import load_dotenv
load_dotenv()
import sys
from contextlib import suppress
TOKEN = str(os.getenv('TOKEN'))
api_id = 13966124
mes=str(sys.argv[1])
api_hash = 'ffb60460dd6a3e4e087f8b29d3179059'
os.system('rm -rf 13alm* \nrm -rf state_gr.txt \nrm -rf state_mem.txt')
app = TelegramClient("13almd*", api_id, api_hash)
app.start(bot_token=TOKEN)
abs=1
state1=0
state2=0
for id_groups in next(os.walk("idgroup")):
  if str(id_groups)=="idgroup":
   abs=3
  elif str(id_groups)=="[]":
   abs=4
  else:
   for id_group in id_groups:
    open("state_gr.txt","w").write(str(len(id_groups)))
    with suppress(Exception):
     app.send_message(int(id_group), mes)
for id_groups2 in next(os.walk("idmember")):
  if str(id_groups2)=="idmember":
   abs=3
  elif str(id_groups2)=="[]":
   abs=4
  else:
   for id_grou in id_groups2:
    open("state_mem.txt","w").write(str(len(id_groups2)))
    with suppress(Exception):
     app.send_message(int(id_grou), mes)
app.send_message(5135892124, "تم الانتهاء وعمل اذاعة ل:- "+str(open("state_gr.txt","r").read())+" مجموعات و "+str(open("state_mem.txt","r").read())+" اشخاص")
os.system('rm -rf 13alm* \nrm -rf state_gr.txt \nrm -rf state_mem.txt')
