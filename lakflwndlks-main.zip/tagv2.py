from telethon import TelegramClient, sync
import os,time
from dotenv import load_dotenv
load_dotenv()
import sys
TOKEN = str(os.getenv('TOKEN'))
api_id = 13966124
api_hash = 'ffb60460dd6a3e4e087f8b29d3179059'
group = int(sys.argv[1])
tim=int(sys.argv[2])
print(tim)
tagres=""
os.system('rm -rf session/'+str(group)+"v2*")
overFourMentionsSum, totalUsers, userhb = [0, 0, 0]
storeMentionsWithString, StoreMentionsArray= "", []
app = TelegramClient("session/"+str(group)+"v2", api_id, api_hash)
app.connect() 
i=0
app.start(bot_token=TOKEN)
hellos=["","مس يحلو😔❤","مشتاقين🥺","تع نتزوج🤤💍","ممكن نتعرف؟😔","كافي طمس😂","كراشي🥺😂","شني هلجمال🤤","تع بوسك🥺","هلو يلكيك","نطيني بوثه🥺❤","حبيبتك تريدك😂","من وين؟","شكد عمرك؟","ياصف؟","نايم كاعد😉😂","تحبني؟","كافي نوم","شسمك","• تعا نورنه 😉🤍","تعال لك وين طامس","حنسوي العاب تعا 🌚💗","الطف مخلوق حياتي 💖","احبك يحلو 😂","يقمر🥺🥰","مس جميليِ",  "هل تقبل الزواج مني؟","تع نزوج بلسر🤤","تاك لاحب شخص على قلبي🥺❤","ممحححح","احبي الك ادمان🤤❤","احبك😔❤","اشتاقيت للمعان عيونك🥺🥺"]#32
while True:
  for user in app.iter_participants(group):  # Get all participants.
           if user.id and user.first_name and not user.bot and not user.deleted:
            if open("start/"+str(group)+"v2"+".txt","r").read()=="start":
               if open("start/"+str(group)+"v2"+".txt","r").read()=="start":
                userhb += 1
               else:
                app.send_message(group, "تم ايقاف عمل تاك للتعارف بنجاح")
                sys.exit()
                exit()
               overFourMentionsSum += 1
               totalUsers += 1
               if i>=32:
                i=0
               i=i+1
               tagres=hellos[i]+f" [{user.first_name}](tg://user?id={user.id})"
               storeMentionsWithString +=str(tagres)
               if overFourMentionsSum == 1:
                if open("start/"+str(group)+"v2"+".txt","r").read()=="start":
                 app.send_message(group, storeMentionsWithString)
                 time.sleep(tim)
                 storeMentionsWithString, overFourMentionsSum, userhb = "", 0, 0
                else:
                 app.send_message(group, "تم ايقاف عمل تاك للتعارف بنجاح")
                 sys.exit()
                 exit()
            else:
               app.send_message(group, "تم ايقاف عمل تاك للتعارف بنجاح")
               sys.exit()
               exit()
