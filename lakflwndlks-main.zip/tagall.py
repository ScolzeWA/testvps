from telethon import TelegramClient, sync
import os
from dotenv import load_dotenv
load_dotenv()
import sys,time
TOKEN = str(os.getenv('TOKEN'))
api_id = 13966124
api_hash = 'ffb60460dd6a3e4e087f8b29d3179059'
group = int(sys.argv[1])
os.system('rm -rf session/'+str(group)+"*")
tagres=""
tager=0
reloop=7
StoreBots, StoreBannedUsers, = [0, 0]
overFourMentionsSum, totalUsers, userhb = [0, 0, 0]
storeMentionsWithString, StoreMentionsArray, msg, ll = "", [], str(sys.argv[2]), ""
app = TelegramClient("session/"+str(group), api_id, api_hash)
app.connect() 
app.start(bot_token=TOKEN)
def sttag():
        dm_start=int(open("stats/tages.txt","r").read())
        dm_start+=1
        open("start/"+str(group)+".txt","w").write("اللهم عجل لوليك الفرج اللهم صل على محمد وال محمد وعجل فرجهم ولعن عدوهم")
        open("stats/tages.txt","w").write(str(dm_start))
members=[]
a=0
for user in app.iter_participants(group):  # Get all participants.
           if user.id:
            members.append(user.id)
           if user.id and user.first_name and not user.bot and not user.deleted:
            
            if open("start/"+str(group)+".txt","r").read()=="start":
               if open("start/"+str(group)+".txt","r").read()=="start":
                userhb += 1
               else:
                app.send_message(group, "تم ايقاف عمل تاك للكل بنجاح")
                sys.exit()
                exit()
               overFourMentionsSum += 1
               totalUsers += 1
               tager=tager+1
               a=a+1
               if a==4000:
                time.sleep(20)
               tagres=str(totalUsers)+"- " + f"["+str(user.first_name)+"](tg://user?id="+str(user.id)+")\n"
               storeMentionsWithString +=str(tagres)
               if overFourMentionsSum == reloop:
                if open("start/"+str(group)+".txt","r").read()=="start":
                 app.send_message(group, str(ll)+storeMentionsWithString+"\n"+str(msg)+str(ll))
                 time.sleep(3)
                 storeMentionsWithString, overFourMentionsSum, userhb = "", 0, 0
                else:
                 app.send_message(group, "تم ايقاف عمل تاك للكل بنجاح")
                 sys.exit()
                 exit()
            else:
               app.send_message(group, "تم ايقاف عمل تاك للكل بنجاح")
               sys.exit()
               exit()
           elif user.bot:
              StoreBots+=1
           else:
            StoreBannedUsers+=1
if overFourMentionsSum < reloop:
  if open("start/"+str(group)+".txt","r").read()=="start":
              app.send_message(group, str(ll)+storeMentionsWithString+"\n"+str(msg)+str(ll))
              storeMentionsWithString, overFourMentionsSum, userhb = "", 0, 0
  else:
             app.send_message(group, "تم ايقاف عمل تاك للكل بنجاح")
             sys.exit()
             exit()
if a>9900 or a==9900:
 app.send_message(group,
            f"تم الانتهاء\n وصلنا الى الحد الاقصى من تاكات وهو:-"+str(a)+f"\nتم عمل تاك ل {str(totalUsers)} عضو\nحسابات لم يتم عمل تاك لها:-"+str(len(members)-tager)+f"\nحسابات بوتات:- {StoreBots}\nحسابات محذوفه:-"+str(len(members)-tager-StoreBots))
elif a<9900:
 app.send_message(group,
            f"تم الانتهاء\nتم عمل تاك ل {str(totalUsers)} عضو\nحسابات لم يتم عمل تاك لها:-"+str(len(members)-tager)+f"\nحسابات بوتات:- {StoreBots}\nحسابات محذوفه:-"+str(len(members)-tager-StoreBots))
sttag()