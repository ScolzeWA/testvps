<?php
include 'index.php';
var_dump(checkYahoo('gul64900@yahoo.com'));