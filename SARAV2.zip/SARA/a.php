<?php
include 'index.php';
var_dump(checkGmail('gul64900@gmail.com'));